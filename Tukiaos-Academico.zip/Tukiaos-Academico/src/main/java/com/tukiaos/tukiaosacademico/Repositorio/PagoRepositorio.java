package com.tukiaos.tukiaosacademico.Repositorio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Pago;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PagoRepositorio extends JpaRepository<Pago, Long> {

    // Método que ya deberías tener
    List<Pago> findByPension(Pension pension);

    // ✅ MÉTODO NUEVO: Buscar pagos por alumno (a través de pensión)
    List<Pago> findByPension_Alumno(Alumno alumno);
}
