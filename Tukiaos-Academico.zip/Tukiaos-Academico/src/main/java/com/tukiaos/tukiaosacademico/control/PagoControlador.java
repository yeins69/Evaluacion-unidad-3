package com.tukiaos.tukiaosacademico.control;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Pago;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import com.tukiaos.tukiaosacademico.Servicio.AlumnoServicio;
import com.tukiaos.tukiaosacademico.Servicio.PagoServicio;
import com.tukiaos.tukiaosacademico.Servicio.PensionServicio;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
public class PagoControlador {

    @FXML private ComboBox<Alumno> cbxAlumno;
    @FXML private TextField txtMonto;
    @FXML private Label lblDeuda;
    @FXML private Label lblMsg;
    @FXML private TableView<Pension> tableView;
    @FXML private TableColumn<Pension, String> colCurso;
    @FXML private TableColumn<Pension, String> colMonto;
    @FXML private TableColumn<Pension, String> colEstado;
    @FXML private TableColumn<Pension, String> colPeriodo;

    @Autowired private PagoServicio pagoServicio;
    @Autowired private AlumnoServicio alumnoServicio;
    @Autowired private PensionServicio pensionServicio;

    private Pension pensionSeleccionada;

    @FXML
    public void initialize() {
        cbxAlumno.setItems(FXCollections.observableArrayList(alumnoServicio.listarEntidad()));
        cbxAlumno.setOnAction(e -> cargarPensionesYDeuda());
        configurarTabla();
    }

    private void configurarTabla() {
        colCurso.setCellValueFactory(data ->
                new ReadOnlyStringWrapper(data.getValue().getCurso().getNombreCurso()));
        colMonto.setCellValueFactory(data ->
                new ReadOnlyStringWrapper(data.getValue().getMonto()));
        colEstado.setCellValueFactory(data ->
                new ReadOnlyStringWrapper(data.getValue().getEstado()));
        colPeriodo.setCellValueFactory(data ->
                new ReadOnlyStringWrapper(data.getValue().getPeriodo().getNombrePeriodo()));

        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            pensionSeleccionada = newSelection;
        });
    }

    private void cargarPensionesYDeuda() {
        Alumno alumno = cbxAlumno.getValue();
        if (alumno != null) {
            List<Pension> pensiones = pensionServicio.buscarPorAlumno(alumno);
            tableView.setItems(FXCollections.observableArrayList(pensiones));

            double deudaTotal = pensiones.stream()
                    .filter(p -> "Pendiente".equalsIgnoreCase(p.getEstado()))
                    .mapToDouble(p -> Double.parseDouble(p.getMonto()))
                    .sum();

            lblDeuda.setText("Deuda total: S/ " + deudaTotal);
        }
    }

    @FXML
    public void registrarPago() {
        if (pensionSeleccionada == null) {
            lblMsg.setText("Seleccione una pensión de la tabla.");
            return;
        }

        String monto = txtMonto.getText();
        if (monto.isEmpty()) {
            lblMsg.setText("Ingrese un monto.");
            return;
        }

        Pago pago = new Pago(null, pensionSeleccionada, monto, LocalDate.now());
        pagoServicio.guardarEntidad(pago);

        // Marcar la pensión como pagada si ya se pagó por completo
        pensionSeleccionada.setEstado("Pagado");
        pensionServicio.guardarEntidad(pensionSeleccionada);

        lblMsg.setText("Pago registrado correctamente.");
        cargarPensionesYDeuda();
        txtMonto.clear();
    }
}
