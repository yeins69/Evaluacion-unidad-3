package com.tukiaos.tukiaosacademico.Servicio;

import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;
import com.tukiaos.tukiaosacademico.Repositorio.PeriodoAcademicoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PeriodoAcademicoServicio {

    @Autowired
    private PeriodoAcademicoRepositorio repository;

    public List<PeriodoAcademico> listarEntidad() {
        return repository.findAll();
    }

    public PeriodoAcademico guardarEntidad(PeriodoAcademico periodo) {
        return repository.save(periodo);
    }

    public PeriodoAcademico buscarPorNombre(String nombre) {
        return repository.findByNombrePeriodo(nombre);
    }

    public void eliminarEntidad(Long id) {
        repository.deleteById(id);
    }

    public PeriodoAcademico actualizarEntidad(PeriodoAcademico periodo) {
        return repository.save(periodo);
    }
}
