package com.tukiaos.tukiaosacademico.Modelo;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tukiaos_pension")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Pension {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPension;

    @ManyToOne
    @JoinColumn(name = "id_alumno")
    private Alumno alumno;

    @ManyToOne
    @JoinColumn(name = "id_curso")
    private Curso curso;

    @ManyToOne
    @JoinColumn(name = "id_periodo")
    private PeriodoAcademico periodo;

    private String concepto;

    private String monto;

    private String estado;
}
