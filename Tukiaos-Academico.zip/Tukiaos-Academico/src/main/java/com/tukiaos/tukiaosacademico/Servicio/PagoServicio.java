package com.tukiaos.tukiaosacademico.Servicio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Pago;
import com.tukiaos.tukiaosacademico.Modelo.Pension;

import java.util.List;

public interface PagoServicio {
    Pago guardarEntidad(Pago pago);
    List<Pago> buscarPorPension(Pension pension);
    List<Pago> buscarPorAlumno(Alumno alumno);

}
