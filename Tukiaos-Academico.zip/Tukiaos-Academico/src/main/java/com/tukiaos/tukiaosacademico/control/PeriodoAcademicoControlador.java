package com.tukiaos.tukiaosacademico.control;

import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;
import com.tukiaos.tukiaosacademico.Servicio.PeriodoAcademicoServicio;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
public class PeriodoAcademicoControlador {

    @FXML private TextField txtNombrePeriodo;
    @FXML private DatePicker dpInicio;
    @FXML private DatePicker dpFin;
    @FXML private ComboBox<String> cbxEstado;
    @FXML private Label lblMsg;
    @FXML private TableView<PeriodoAcademico> tableView;
    @FXML private TableColumn<PeriodoAcademico, String> colNombre;
    @FXML private TableColumn<PeriodoAcademico, String> colInicio;
    @FXML private TableColumn<PeriodoAcademico, String> colFin;
    @FXML private TableColumn<PeriodoAcademico, String> colEstado;

    @Autowired private PeriodoAcademicoServicio periodoServicio;

    private ObservableList<PeriodoAcademico> datos;

    @FXML
    public void initialize() {
        cbxEstado.setItems(FXCollections.observableArrayList("Activo", "Inactivo"));
        cbxEstado.setValue("Activo");
        dpInicio.setValue(LocalDate.now());
        cargarTabla();
        listarDatos();
    }

    private void cargarTabla() {
        colNombre.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getNombrePeriodo()));
        colInicio.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getFechaInicio().toString()));
        colFin.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getFechaFin().toString()));
        colEstado.setCellValueFactory(c -> new ReadOnlyStringWrapper(c.getValue().getEstado()));
    }

    private void listarDatos() {
        List<PeriodoAcademico> lista = periodoServicio.listarEntidad();
        datos = FXCollections.observableArrayList(lista);
        tableView.setItems(datos);
    }

    @FXML
    private void guardarPeriodo() {
        String nombre = txtNombrePeriodo.getText();
        LocalDate inicio = dpInicio.getValue();
        LocalDate fin = dpFin.getValue();
        String estado = cbxEstado.getValue();

        if (nombre.isEmpty() || inicio == null || fin == null || estado == null) {
            lblMsg.setText("Complete todos los campos.");
            return;
        }

        PeriodoAcademico p = PeriodoAcademico.builder()
                .nombrePeriodo(nombre)
                .fechaInicio(inicio)
                .fechaFin(fin)
                .estado(estado)
                .build();

        periodoServicio.guardarEntidad(p);
        lblMsg.setText("Periodo guardado correctamente.");
        limpiar();
        listarDatos();
    }

    @FXML
    private void eliminarPeriodo() {
        PeriodoAcademico seleccionado = tableView.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            periodoServicio.eliminarEntidad(seleccionado.getIdPeriodo());
            lblMsg.setText("Periodo eliminado correctamente.");
            listarDatos();
        } else {
            lblMsg.setText("Seleccione un periodo para eliminar.");
        }
    }

    private void limpiar() {
        txtNombrePeriodo.clear();
        dpInicio.setValue(null);
        dpFin.setValue(null);
        cbxEstado.setValue(null);
    }
}
