package com.tukiaos.tukiaosacademico.control;

import com.tukiaos.tukiaosacademico.Modelo.*;
import com.tukiaos.tukiaosacademico.Servicio.*;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Component
public class MatriculaControlador {

    @FXML private DatePicker dpFechaMatricula;
    @FXML private TextField txtCosto;
    @FXML private ComboBox<Curso> cbxCurso;
    @FXML private ComboBox<Alumno> cbxAlumno;
    @FXML private ComboBox<String> cbxEstado;
    @FXML private ComboBox<PeriodoAcademico> cbxPeriodo;
    @FXML private Label lbnMsg;
    @FXML private TableView<Matricula> tableView;
    @FXML private TextField txtFiltroDato;

    @Autowired private MatriculaServicio matriculaServicio;
    @Autowired private CursoServicio cursoServicio;
    @Autowired private AlumnoServicio alumnoServicio;
    @Autowired private PeriodoAcademicoServicio periodoAcademicoServicio;

    private ObservableList<Matricula> datos;
    private Matricula matriculaSeleccionada;

    @FXML
    public void initialize() {
        cargarCombos();
        cargarTabla();
        limpiarFormulario();
        configurarEventosTabla();
        configurarFiltro();

        cbxCurso.setOnAction(event -> {
            Curso cursoSeleccionado = cbxCurso.getValue();
            if (cursoSeleccionado != null && cursoSeleccionado.getCosto() != null) {
                txtCosto.setText(String.valueOf(cursoSeleccionado.getCosto()));
            }
        });
        dpFechaMatricula.setValue(LocalDate.now());
        cbxEstado.getSelectionModel().select("Activo");

    }

    private void cargarCombos() {
        cbxCurso.setItems(FXCollections.observableArrayList(cursoServicio.listarEntidad()));
        cbxAlumno.setItems(FXCollections.observableArrayList(alumnoServicio.listarEntidad()));
        cbxEstado.setItems(FXCollections.observableArrayList(Arrays.asList("Activo", "Inactivo")));
        cbxPeriodo.setItems(FXCollections.observableArrayList(periodoAcademicoServicio.listarEntidad()));
    }

    private void cargarTabla() {
        TableColumn<Matricula, String> colFecha = new TableColumn<>("Fecha Matrícula");
        colFecha.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getFechaMatricula().toString()));

        TableColumn<Matricula, String> colCosto = new TableColumn<>("Costo");
        colCosto.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getCosto()));

        TableColumn<Matricula, String> colCurso = new TableColumn<>("Curso");
        colCurso.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getCurso().getNombreCurso()));

        TableColumn<Matricula, String> colAlumno = new TableColumn<>("Alumno");
        colAlumno.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getAlumno().getNombres()));

        TableColumn<Matricula, String> colEstado = new TableColumn<>("Estado");
        colEstado.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getEstado()));

        TableColumn<Matricula, String> colPeriodo = new TableColumn<>("Periodo");
        colPeriodo.setCellValueFactory(c ->
                new ReadOnlyStringWrapper(
                        c.getValue().getPeriodo() != null ? c.getValue().getPeriodo().getNombrePeriodo() : ""
                )
        );

        tableView.getColumns().setAll(colFecha, colCosto, colCurso, colAlumno, colEstado, colPeriodo);
        listarDatos();
    }

    private void listarDatos() {
        List<Matricula> lista = matriculaServicio.listarEntidad();
        datos = FXCollections.observableArrayList(lista);
        tableView.setItems(datos);
    }

    private void configurarEventosTabla() {
        tableView.setRowFactory(tv -> {
            TableRow<Matricula> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 2) {
                    matriculaSeleccionada = row.getItem();
                    cargarFormulario(matriculaSeleccionada);
                }
            });
            return row;
        });
    }

    private void configurarFiltro() {
        txtFiltroDato.textProperty().addListener((obs, oldValue, newValue) -> {
            if (newValue == null || newValue.isEmpty()) {
                tableView.setItems(datos);
                return;
            }
            String lowerCaseFilter = newValue.toLowerCase();
            Predicate<Matricula> filtro = m ->
                    m.getAlumno().getNombres().toLowerCase().contains(lowerCaseFilter) ||
                    m.getCurso().getNombreCurso().toLowerCase().contains(lowerCaseFilter);
            List<Matricula> filtrada = datos.stream().filter(filtro).collect(Collectors.toList());
            tableView.setItems(FXCollections.observableArrayList(filtrada));
        });
    }

    private void cargarFormulario(Matricula matricula) {
        dpFechaMatricula.setValue(matricula.getFechaMatricula());
        txtCosto.setText(matricula.getCosto());
        cbxCurso.setValue(matricula.getCurso());
        cbxAlumno.setValue(matricula.getAlumno());
        cbxEstado.setValue(matricula.getEstado());
        cbxPeriodo.setValue(matricula.getPeriodo());
    }

    @FXML
    public void validarFormulario() {
        boolean vacio = false;
        lbnMsg.setText("");

        if (dpFechaMatricula.getValue() == null) {
            dpFechaMatricula.setStyle("-fx-border-color: red;");
            vacio = true;
        } else {
            dpFechaMatricula.setStyle(null);
        }

        if (txtCosto.getText().isEmpty()) {
            txtCosto.setStyle("-fx-border-color: red;");
            txtCosto.setPromptText("Ingrese costo");
            vacio = true;
        } else {
            txtCosto.setStyle(null);
        }

        if (cbxCurso.getValue() == null) {
            cbxCurso.setStyle("-fx-border-color: red;");
            vacio = true;
        } else {
            cbxCurso.setStyle(null);
        }

        if (cbxAlumno.getValue() == null) {
            cbxAlumno.setStyle("-fx-border-color: red;");
            vacio = true;
        } else {
            cbxAlumno.setStyle(null);
        }

        if (cbxEstado.getValue() == null) {
            cbxEstado.setStyle("-fx-border-color: red;");
            vacio = true;
        } else {
            cbxEstado.setStyle(null);
        }

        if (cbxPeriodo.getValue() == null) {
            cbxPeriodo.setStyle("-fx-border-color: red;");
            vacio = true;
        } else {
            cbxPeriodo.setStyle(null);
        }

        if (vacio) {
            lbnMsg.setStyle("-fx-text-fill: red;");
            lbnMsg.setText("Todos los campos son obligatorios.");
            return;
        }

        Alumno alumno = cbxAlumno.getValue();
        if (alumno.getApoderado() == null) {
            lbnMsg.setStyle("-fx-text-fill: red;");
            lbnMsg.setText("El alumno no tiene apoderado asignado.");
            return;
        }

        Matricula nuevaMatricula = matriculaSeleccionada == null ? new Matricula() : matriculaSeleccionada;
        nuevaMatricula.setFechaMatricula(dpFechaMatricula.getValue());
        nuevaMatricula.setCosto(txtCosto.getText());
        nuevaMatricula.setCurso(cbxCurso.getValue());
        nuevaMatricula.setAlumno(cbxAlumno.getValue());
        nuevaMatricula.setEstado(cbxEstado.getValue());
        nuevaMatricula.setPeriodo(cbxPeriodo.getValue());
        nuevaMatricula.setApoderado(alumno.getApoderado());

        matriculaServicio.guardarEntidad(nuevaMatricula);

        lbnMsg.setStyle("-fx-text-fill: green;");
        lbnMsg.setText(matriculaSeleccionada == null ? "Matrícula guardada correctamente." : "Matrícula actualizada correctamente.");

        listarDatos();
        limpiarFormulario();
        matriculaSeleccionada = null;
    }

    @FXML
    public void eliminarMatricula() {
        Matricula seleccionada = tableView.getSelectionModel().getSelectedItem();
        if (seleccionada != null) {
            matriculaServicio.eliminarRegEntidad(seleccionada.getIdMatricula());
            lbnMsg.setStyle("-fx-text-fill: green;");
            lbnMsg.setText("Matrícula eliminada correctamente.");
            listarDatos();
            limpiarFormulario();
        } else {
            lbnMsg.setStyle("-fx-text-fill: red;");
            lbnMsg.setText("Seleccione una matrícula para eliminar.");
        }
    }

    private void limpiarFormulario() {
        dpFechaMatricula.setValue(null);
        txtCosto.clear();
        cbxCurso.getSelectionModel().clearSelection();
        cbxAlumno.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().clearSelection();
        cbxPeriodo.getSelectionModel().clearSelection();
        dpFechaMatricula.setStyle(null);
        txtCosto.setStyle(null);
        cbxCurso.setStyle(null);
        cbxAlumno.setStyle(null);
        cbxEstado.setStyle(null);
        cbxPeriodo.setStyle(null);
        matriculaSeleccionada = null;
    }
}
