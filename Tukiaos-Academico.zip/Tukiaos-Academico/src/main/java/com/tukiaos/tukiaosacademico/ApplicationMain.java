package com.tukiaos.tukiaosacademico;

public class ApplicationMain {
    public static void main(String[] args) {
        TukiaosAcademicoApplication.main(args);
    }
}
