package com.tukiaos.tukiaosacademico.Servicio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Curso;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;
import com.tukiaos.tukiaosacademico.Repositorio.PensionRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PensionServicioImpl implements PensionServicio {

    @Autowired
    private PensionRepositorio repositorio;

    @Override
    public void guardar(Pension pension) {
        repositorio.save(pension);
    }
    @Override
    public void guardarEntidad(Pension pension) {
        repositorio.save(pension);
    }

    @Override
    public void eliminarEntidad(Long id) {
        repositorio.deleteById(id);
    }

    @Override
    public void eliminar(Long id) {
        repositorio.deleteById(id);
    }

    @Override
    public List<Pension> listarTodo() {
        return repositorio.findAll();
    }
    @Override
    public boolean existePension(Alumno alumno, Curso curso, PeriodoAcademico periodo) {
        return repositorio.findByAlumnoAndCursoAndPeriodo(alumno, curso, periodo).isPresent();
    }

    @Override
    public List<Pension> buscarPorAlumno(Alumno alumno) {
        return repositorio.findByAlumno(alumno);
    }

    @Override
    public List<Pension> buscarPorAlumnoYEstado(Alumno alumno, String estado) {
        return repositorio.findByAlumnoAndEstado(alumno, estado);
    }
}
