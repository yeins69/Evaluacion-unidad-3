package com.tukiaos.tukiaosacademico.Modelo;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPago;

    @ManyToOne
    @JoinColumn(name = "id_pension", nullable = false)
    private Pension pension;

    @Column(name = "monto", nullable = false)
    private String monto;

    @Column(name = "fecha", nullable = false) // <- Asegúrate que tu DB use esta columna
    private LocalDate fecha;
}
