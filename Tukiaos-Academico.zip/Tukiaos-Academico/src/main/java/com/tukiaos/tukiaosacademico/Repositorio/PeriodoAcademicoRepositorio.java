package com.tukiaos.tukiaosacademico.Repositorio;

import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PeriodoAcademicoRepositorio extends JpaRepository<PeriodoAcademico, Long> {
    PeriodoAcademico findByNombrePeriodo(String nombrePeriodo);
}
