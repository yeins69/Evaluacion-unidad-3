package com.tukiaos.tukiaosacademico.Servicio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Curso;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;

import java.util.List;

public interface PensionServicio {
    void guardar(Pension pension);
    void eliminar(Long id);
    void guardarEntidad(Pension pension);
    void eliminarEntidad(Long id);
    List<Pension> listarTodo();
    List<Pension> buscarPorAlumno(Alumno alumno);
    List<Pension> buscarPorAlumnoYEstado(Alumno alumno, String estado);
    boolean existePension(Alumno alumno, Curso curso, PeriodoAcademico periodo);

}
