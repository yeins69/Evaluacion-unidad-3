package com.tukiaos.tukiaosacademico.control;

import com.tukiaos.tukiaosacademico.Modelo.*;
import com.tukiaos.tukiaosacademico.Servicio.*;

import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PensionControlador {

    @FXML private ComboBox<Alumno> cbxAlumno;
    @FXML private ComboBox<Curso> cbxCurso;
    @FXML private ComboBox<PeriodoAcademico> cbxPeriodo;
    @FXML private TextField txtConcepto;
    @FXML private TextField txtMonto;
    @FXML private ComboBox<String> cbxEstado;
    @FXML private Label lblMsg;
    @FXML private Label lblDeudaTotal;
    @FXML private TableView<Pension> tableView;
    @FXML private TableColumn<Pension, String> colCurso;
    @FXML private TableColumn<Pension, String> colPeriodo;
    @FXML private TableColumn<Pension, String> colConcepto;
    @FXML private TableColumn<Pension, String> colMonto;
    @FXML private TableColumn<Pension, String> colEstado;

    @Autowired private PensionServicio pensionServicio;
    @Autowired private AlumnoServicio alumnoServicio;
    @Autowired private CursoServicio cursoServicio;
    @Autowired private PeriodoAcademicoServicio periodoAcademicoServicio;
    @Autowired private MatriculaServicio matriculaServicio;

    private Pension pensionSeleccionada;

    @FXML
    public void initialize() {
        cargarCombos();
        configurarColumnas();
        cbxAlumno.setOnAction(e -> mostrarPensionesPorAlumno());
    }

    private void cargarCombos() {
        cbxAlumno.setItems(FXCollections.observableArrayList(alumnoServicio.listarEntidad()));
        cbxCurso.setItems(FXCollections.observableArrayList(cursoServicio.listarEntidad()));
        cbxPeriodo.setItems(FXCollections.observableArrayList(periodoAcademicoServicio.listarEntidad()));
        cbxEstado.setItems(FXCollections.observableArrayList("Pagado", "Pendiente"));
    }

    private void configurarColumnas() {
        colCurso.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getCurso().getNombreCurso()));
        colPeriodo.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getPeriodo().getNombrePeriodo()));
        colConcepto.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getConcepto()));
        colMonto.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getMonto()));
        colEstado.setCellValueFactory(data -> new ReadOnlyStringWrapper(data.getValue().getEstado()));

        tableView.setRowFactory(tv -> {
            TableRow<Pension> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty() && event.getClickCount() == 2) {
                    pensionSeleccionada = row.getItem();
                    cargarFormulario(pensionSeleccionada);
                }
            });
            return row;
        });
    }

    private void mostrarPensionesPorAlumno() {
        Alumno alumno = cbxAlumno.getValue();
        if (alumno != null) {
            // Buscar todas las matrículas del alumno
            List<Matricula> matriculas = matriculaServicio.buscarPorAlumno(alumno.getIdAlumno());

            for (Matricula m : matriculas) {
                boolean yaExiste = pensionServicio.existePension(alumno, m.getCurso(), m.getPeriodo());
                if (!yaExiste) {
                    Pension nueva = new Pension();
                    nueva.setAlumno(alumno);
                    nueva.setCurso(m.getCurso());
                    nueva.setPeriodo(m.getPeriodo());
                    nueva.setConcepto("Pensión de curso");
                    nueva.setMonto(m.getCosto()); // ← desde matrícula
                    nueva.setEstado("Pendiente");
                    pensionServicio.guardarEntidad(nueva);
                }
            }

            // Obtener todas las pensiones ya registradas del alumno
            List<Pension> pensiones = pensionServicio.buscarPorAlumno(alumno);
            tableView.setItems(FXCollections.observableArrayList(pensiones));

            // Calcular deuda total
            double deudaTotal = pensiones.stream()
                    .filter(p -> "Pendiente".equalsIgnoreCase(p.getEstado()))
                    .mapToDouble(p -> Double.parseDouble(p.getMonto()))
                    .sum();

            lblDeudaTotal.setText("Deuda Total: S/ " + String.format("%.2f", deudaTotal));
        }
    }

    private void cargarFormulario(Pension pension) {
        cbxAlumno.setValue(pension.getAlumno());
        cbxCurso.setValue(pension.getCurso());
        cbxPeriodo.setValue(pension.getPeriodo());
        txtConcepto.setText(pension.getConcepto());
        txtMonto.setText(pension.getMonto());
        cbxEstado.setValue(pension.getEstado());
    }

    private void limpiarFormulario() {
        cbxAlumno.getSelectionModel().clearSelection();
        cbxCurso.getSelectionModel().clearSelection();
        cbxPeriodo.getSelectionModel().clearSelection();
        txtConcepto.clear();
        txtMonto.clear();
        cbxEstado.getSelectionModel().clearSelection();
        pensionSeleccionada = null;
    }
}
