package com.tukiaos.tukiaosacademico.control;

import com.tukiaos.tukiaosacademico.Modelo.Profesor;
import com.tukiaos.tukiaosacademico.Servicio.ProfesorServicio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProfesorControlado {

    @Autowired
    private ProfesorServicio profesorServicio;

    @FXML private TextField txtNombres;
    @FXML private TextField txtApellidoPaterno;
    @FXML private TextField txtApellidoMaterno;
    @FXML private TextField txtDni;
    @FXML private TextField txtCelular;
    @FXML private TextField txtDireccion;
    @FXML private DatePicker dpFechaContratacion;
    @FXML private Label lbnMsg;
    @FXML private TextField txtFiltroDato;
    @FXML private TableView<Profesor> tableView;

    private ObservableList<Profesor> profesorList;
    private Profesor profesorSeleccionado;

    @FXML
    public void initialize() {
        cargarColumnas();
        cargarDatos();

        txtFiltroDato.textProperty().addListener((obs, oldVal, newVal) -> filtrarProfesores());

        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                profesorSeleccionado = newSel;
                cargarFormularioDesdeSeleccionado();
            }
        });
        dpFechaContratacion.setValue(java.time.LocalDate.now());
    }

    private void cargarColumnas() {
        TableColumn<Profesor, Long> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("idProfesor"));

        TableColumn<Profesor, String> colNombres = new TableColumn<>("Nombres");
        colNombres.setCellValueFactory(new PropertyValueFactory<>("nombres"));

        TableColumn<Profesor, String> colApellidoPaterno = new TableColumn<>("Apellido Paterno");
        colApellidoPaterno.setCellValueFactory(new PropertyValueFactory<>("apellidoPaterno"));

        TableColumn<Profesor, String> colApellidoMaterno = new TableColumn<>("Apellido Materno");
        colApellidoMaterno.setCellValueFactory(new PropertyValueFactory<>("apellidoMaterno"));

        TableColumn<Profesor, String> colDni = new TableColumn<>("DNI");
        colDni.setCellValueFactory(new PropertyValueFactory<>("dni"));

        TableColumn<Profesor, String> colCelular = new TableColumn<>("Celular");
        colCelular.setCellValueFactory(new PropertyValueFactory<>("celular"));

        tableView.getColumns().addAll(colId, colNombres, colApellidoPaterno, colApellidoMaterno, colDni, colCelular);
    }

    private void cargarDatos() {
        List<Profesor> lista = profesorServicio.listarEntidad();
        profesorList = FXCollections.observableArrayList(lista);
        tableView.setItems(profesorList);
    }

    private void filtrarProfesores() {
        String filtro = txtFiltroDato.getText().toLowerCase().trim();
        if (filtro.isEmpty()) {
            tableView.setItems(profesorList);
        } else {
            ObservableList<Profesor> filtrados = profesorList.filtered(p ->
                    p.getNombres().toLowerCase().contains(filtro) ||
                    p.getApellidoPaterno().toLowerCase().contains(filtro) ||
                    p.getApellidoMaterno().toLowerCase().contains(filtro) ||
                    p.getDni().toLowerCase().contains(filtro)
            );
            tableView.setItems(filtrados);
        }
    }

    @FXML
    public void validarFormulario(ActionEvent event) {
        resetearEstilos();

        if (camposVacios()) {
            lbnMsg.setStyle("-fx-text-fill: red;");
            lbnMsg.setText("Todos los campos son obligatorios.");

            if (txtNombres.getText().isEmpty()) txtNombres.setStyle("-fx-border-color: red;");txtNombres.setPromptText("Ingrese nombres");
            if (txtApellidoPaterno.getText().isEmpty()) txtApellidoPaterno.setStyle("-fx-border-color: red;");txtApellidoPaterno.setPromptText("Ingrese Apellido");
            if (txtApellidoMaterno.getText().isEmpty()) txtApellidoMaterno.setStyle("-fx-border-color: red;");txtApellidoMaterno.setPromptText("Ingrese Apellido");
            if (txtDni.getText().isEmpty()) txtDni.setStyle("-fx-border-color: red;");txtDni.setPromptText("Ingrese DNI");
            if (txtCelular.getText().isEmpty()) txtCelular.setStyle("-fx-border-color: red;");txtCelular.setPromptText("Ingrese Celular");
            if (txtDireccion.getText().isEmpty()) txtDireccion.setStyle("-fx-border-color: red;");txtDireccion.setPromptText("Ingrese DNI");
            if (dpFechaContratacion.getValue() == null) dpFechaContratacion.setStyle("-fx-border-color: red;");dpFechaContratacion.setPromptText("Ingrese Fecha");
            return;
        }

        if (profesorSeleccionado == null) {
            Profesor profesor = Profesor.builder()
                    .nombres(txtNombres.getText())
                    .apellidoPaterno(txtApellidoPaterno.getText())
                    .apellidoMaterno(txtApellidoMaterno.getText())
                    .dni(txtDni.getText())
                    .celular(txtCelular.getText())
                    .direccion(txtDireccion.getText())
                    .fechaContratacion(dpFechaContratacion.getValue())
                    .build();
            profesorServicio.guardarEntidad(profesor);
            lbnMsg.setStyle("-fx-text-fill: green;");
            lbnMsg.setText("Profesor guardado exitosamente.");
        } else {
            profesorSeleccionado.setNombres(txtNombres.getText());
            profesorSeleccionado.setApellidoPaterno(txtApellidoPaterno.getText());
            profesorSeleccionado.setApellidoMaterno(txtApellidoMaterno.getText());
            profesorSeleccionado.setDni(txtDni.getText());
            profesorSeleccionado.setCelular(txtCelular.getText());
            profesorSeleccionado.setDireccion(txtDireccion.getText());
            profesorSeleccionado.setFechaContratacion(dpFechaContratacion.getValue());

            profesorServicio.guardarEntidad(profesorSeleccionado);
            lbnMsg.setStyle("-fx-text-fill: green;");
            lbnMsg.setText("Profesor actualizado.");
        }

        limpiarFormulario();
        cargarDatos();
    }

    @FXML
    public void eliminarProfesor(ActionEvent event) {
        if (profesorSeleccionado != null) {
            profesorServicio.eliminarRegEntidad(profesorSeleccionado.getIdProfesor());
            lbnMsg.setText("Profesor eliminado.");
            limpiarFormulario();
            cargarDatos();
        } else {
            lbnMsg.setText("Seleccione un profesor para eliminar.");
        }
    }

    private boolean camposVacios() {
        return txtNombres.getText().isEmpty() ||
               txtApellidoPaterno.getText().isEmpty() ||
               txtApellidoMaterno.getText().isEmpty() ||
               txtDni.getText().isEmpty() ||
               txtCelular.getText().isEmpty() ||
               txtDireccion.getText().isEmpty() ||
               dpFechaContratacion.getValue() == null;
    }

    private void resetearEstilos() {
        txtNombres.setStyle("");
        txtApellidoPaterno.setStyle("");
        txtApellidoMaterno.setStyle("");
        txtDni.setStyle("");
        txtCelular.setStyle("");
        txtDireccion.setStyle("");
        dpFechaContratacion.setStyle("");
    }

    private void limpiarFormulario() {
        txtNombres.clear();
        txtApellidoPaterno.clear();
        txtApellidoMaterno.clear();
        txtDni.clear();
        txtCelular.clear();
        txtDireccion.clear();
        dpFechaContratacion.setValue(null);
        profesorSeleccionado = null;
        resetearEstilos();
        tableView.getSelectionModel().clearSelection();
    }

    private void cargarFormularioDesdeSeleccionado() {
        txtNombres.setText(profesorSeleccionado.getNombres());
        txtApellidoPaterno.setText(profesorSeleccionado.getApellidoPaterno());
        txtApellidoMaterno.setText(profesorSeleccionado.getApellidoMaterno());
        txtDni.setText(profesorSeleccionado.getDni());
        txtCelular.setText(profesorSeleccionado.getCelular());
        txtDireccion.setText(profesorSeleccionado.getDireccion());
        dpFechaContratacion.setValue(profesorSeleccionado.getFechaContratacion());
    }
}
