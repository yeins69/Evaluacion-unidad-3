package com.tukiaos.tukiaosacademico.Modelo;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "tukiaos_curso")
public class Curso {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long idCurso;

  @Column(nullable = false)
  private String nombreCurso;

  @Column(nullable = false)
  private String horasSemana;

  @Column(nullable = false)
  private Double costo;
  @Override
  public String toString() {
    return nombreCurso;
  }
  @ManyToOne
  @JoinColumn(name = "id_profesor", nullable = false)
  private Profesor profesor;

  @ManyToOne
  @JoinColumn(name = "id_aula", nullable = false)
  private Aula aula;
}
