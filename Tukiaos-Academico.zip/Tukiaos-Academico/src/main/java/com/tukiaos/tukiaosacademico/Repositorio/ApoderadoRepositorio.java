package com.tukiaos.tukiaosacademico.Repositorio;

import com.tukiaos.tukiaosacademico.Modelo.Apoderado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApoderadoRepositorio extends JpaRepository<Apoderado, Long> {
}
