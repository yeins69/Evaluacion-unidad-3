package com.tukiaos.tukiaosacademico.Servicio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Pago;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import com.tukiaos.tukiaosacademico.Repositorio.PagoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PagoServicioImpl implements PagoServicio {

    @Autowired
    private PagoRepositorio pagoRepositorio;

    @Override
    public Pago guardarEntidad(Pago pago) {
        return pagoRepositorio.save(pago);
    }

    @Override
    public List<Pago> buscarPorPension(Pension pension) {
        return pagoRepositorio.findByPension(pension);
    }
    @Override
    public List<Pago> buscarPorAlumno(Alumno alumno) {
        return pagoRepositorio.findByPension_Alumno(alumno);
    }

}
