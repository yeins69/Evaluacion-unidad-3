package com.tukiaos.tukiaosacademico.Repositorio;

import com.tukiaos.tukiaosacademico.Modelo.Alumno;
import com.tukiaos.tukiaosacademico.Modelo.Curso;
import com.tukiaos.tukiaosacademico.Modelo.Pension;
import com.tukiaos.tukiaosacademico.Modelo.PeriodoAcademico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PensionRepositorio extends JpaRepository<Pension, Long> {

    // Buscar todas las pensiones de un alumno
    List<Pension> findByAlumno(Alumno alumno);

    // Buscar pensiones de un alumno por estado (ej. Pendiente, Pagado)
    List<Pension> findByAlumnoAndEstado(Alumno alumno, String estado);
    Optional<Pension> findByAlumnoAndCursoAndPeriodo(Alumno alumno, Curso curso, PeriodoAcademico periodo);

}
