package com.tukiaos.tukiaosacademico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TukiaosAcademicoApplicationTests {

    @Test
    void contextLoads() {
    }

}
